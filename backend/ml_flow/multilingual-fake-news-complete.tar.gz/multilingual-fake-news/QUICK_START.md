# 🚀 QUICK START GUIDE
## Multilingual Fake News Detection System - Complete Setup

This guide will walk you through setting up the entire system from scratch in ~2-3 hours.

---

## ⏱️ Timeline Overview

- **Step 1-3**: Environment setup (30 minutes)
- **Step 4-5**: Dataset preparation (45 minutes)
- **Step 6**: Model training (4-6 hours on GPU, optional)
- **Step 7-8**: Blockchain setup (15 minutes)
- **Step 9-10**: Run application (10 minutes)

**Total (excluding training)**: ~2 hours

---

## 📋 Prerequisites Checklist

Before starting, ensure you have:

- [ ] Python 3.9 or higher installed
- [ ] Node.js 16 or higher installed
- [ ] PostgreSQL 13 or higher installed
- [ ] Git installed
- [ ] 16GB RAM minimum
- [ ] 50GB free disk space
- [ ] GPU (optional but recommended for training)
- [ ] Stable internet connection (for dataset download)

---

## STEP 1: Clone and Navigate

```bash
# Clone the repository
git clone https://github.com/yourusername/multilingual-fake-news-detection.git
cd multilingual-fake-news-detection

# Verify structure
ls -la
# Should see: backend/, blockchain/, frontend/, scripts/, data/, README.md, etc.
```

---

## STEP 2: Python Environment Setup

```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate  # On Linux/Mac
# OR
venv\Scripts\activate     # On Windows

# Upgrade pip
pip install --upgrade pip

# Install dependencies (takes ~10 minutes)
pip install -r requirements.txt --break-system-packages

# Download NLTK data
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"

# Verify installation
python -c "import torch; import transformers; print('✓ PyTorch and Transformers installed')"
```

**Troubleshooting:**
- If `torch` fails to install: Visit https://pytorch.org and install for your system
- If `indic-nlp-library` fails: `pip install git+https://github.com/anoopkunchukuttan/indic_nlp_library.git`

---

## STEP 3: Database Setup

```bash
# Option A: Using createdb command
createdb fakenews

# Option B: Using psql
psql -U postgres
CREATE DATABASE fakenews;
\q

# Verify database exists
psql -U postgres -l | grep fakenews
# Should show 'fakenews' in the list
```

**Update connection string:**

Edit `backend/config.py` and set:
```python
SQLALCHEMY_DATABASE_URI = 'postgresql://YOUR_USER:YOUR_PASSWORD@localhost:5432/fakenews'
```

Replace `YOUR_USER` and `YOUR_PASSWORD` with your PostgreSQL credentials.

---

## STEP 4: Download Dataset

```bash
# Run download script
python scripts/download_data.py
```

**What happens:**
- Downloads 4 zip files (~194 MB total)
- Extracts to `data/raw/` folder
- Creates language-specific directories

**Expected output:**
```
[HINDI]
✓ Downloaded hindi.zip (59.7 MB)
✓ Extracted to Hindi_F&R_News
  → Fake news: ~8,000 articles
  → Real news: ~7,500 articles
  → Total: ~15,500 articles

[GUJARATI]
... (similar output for each language)

✓ Dataset download complete!
```

**Troubleshooting:**
- If download fails: Check internet connection, try again
- If extraction fails: Manually unzip files in `data/raw/`
- If slow: Downloads are large, be patient (~5-10 minutes on slow connections)

---

## STEP 5: Prepare Dataset

```bash
# Run preparation script
python scripts/prepare_dataset.py
```

**What happens:**
- Reads all .txt files from each language
- Cleans and normalizes text
- Creates train/val/test splits
- Saves to `data/processed/`

**Expected output:**
```
=== DATASET STATISTICS ===
Total articles: 42,156

--- By Language ---
Hindi:       15,234
Gujarati:    13,892
Marathi:     12,104
Telugu:       10,926

--- By Label ---
Fake:        21,203 (50.3%)
Real:        20,953 (49.7%)

✓ Split into:
  - Training:   29,509 (70.0%)
  - Validation:  6,324 (15.0%)
  - Testing:     6,323 (15.0%)

✓ DATASET PREPARATION COMPLETE!
```

**Files created:**
- `data/processed/multilingual_dataset.csv` - Full dataset
- `data/processed/train.csv` - Training set
- `data/processed/val.csv` - Validation set
- `data/processed/test.csv` - Test set

---

## STEP 6: Train Model (OPTIONAL)

**Note:** This step takes 4-6 hours on GPU. You can skip this and use a pre-trained model.

```bash
# Start training
python scripts/train_model.py

# Monitor progress
# You'll see epoch-by-epoch updates:
# Epoch 1/5: Train Loss: 0.3421 | Train Acc: 0.8523 | Val Acc: 0.8756
# Epoch 2/5: Train Loss: 0.2134 | Train Acc: 0.9123 | Val Acc: 0.9201
# ...
```

**Expected timeline:**
- GPU (RTX 3090): 4-6 hours
- GPU (T4/V100): 8-12 hours
- CPU: 48+ hours (NOT recommended)

**Output:**
- `data/models/best_model.pth` - Trained model checkpoint

**Alternative - Use Pre-trained Model:**
```bash
# If you have a pre-trained model, place it here:
mkdir -p data/models
cp /path/to/pretrained/model.pth data/models/best_model.pth
```

---

## STEP 7: Blockchain Setup

### 7a. Install Blockchain Tools

```bash
# Install globally
npm install -g truffle ganache-cli

# Verify installation
truffle version
ganache-cli --version
```

### 7b. Start Local Blockchain

**Open a NEW terminal** (keep it running):

```bash
cd multilingual-fake-news-detection

# Start Ganache with deterministic accounts
ganache-cli --deterministic --accounts 10 --gasLimit 10000000

# You should see:
# Available Accounts
# ==================
# (0) 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 (100 ETH)
# (1) 0x70997970C51812dc3A010C7d01b50e0d17dc79C8 (100 ETH)
# ...
#
# Private Keys
# ==================
# (0) 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
# (1) 0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d
# ...
```

**IMPORTANT:** Keep this terminal open! The blockchain must run continuously.

### 7c. Compile and Deploy Smart Contracts

**Open ANOTHER new terminal:**

```bash
cd multilingual-fake-news-detection/blockchain

# Install dependencies
npm install

# Compile contracts
truffle compile

# Expected output:
# Compiling your contracts...
# > Compiling ./contracts/PublisherRegistry.sol
# > Compiling ./contracts/ArticleRegistry.sol
# > Compiling ./contracts/AnnotationRegistry.sol
# > Artifacts written to /path/to/build/contracts
# > Compiled successfully

# Deploy contracts
truffle migrate --network development

# Expected output:
# 1_deploy_contracts.js
# =====================
#    Deploying 'PublisherRegistry'
#    > transaction hash:    0x1234...
#    > contract address:    0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9
#
#    Deploying 'ArticleRegistry'
#    > contract address:    0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9
#
#    Deploying 'AnnotationRegistry'
#    > contract address:    0x5FC8d32690cc91D4c39d9d3abcBD16989F875707
```

**Copy these contract addresses!** You'll need them next.

---

## STEP 8: Configure Backend

```bash
cd backend

# Create environment file
cat > .env << 'EOF'
# Flask
SECRET_KEY=your-super-secret-key-change-this-in-production
DEBUG=True

# Database
DATABASE_URL=postgresql://YOUR_USER:YOUR_PASSWORD@localhost:5432/fakenews

# JWT
JWT_SECRET_KEY=your-jwt-secret-key-change-this

# Blockchain (use addresses from Step 7c)
BLOCKCHAIN_URL=http://127.0.0.1:8545
PUBLISHER_REGISTRY_ADDRESS=0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9
ARTICLE_REGISTRY_ADDRESS=0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9
ANNOTATION_REGISTRY_ADDRESS=0x5FC8d32690cc91D4c39d9d3abcBD16989F875707

# Private key of first Ganache account (from Step 7b)
PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80

# Model
MODEL_PATH=../data/models/best_model.pth
BERT_MODEL=ai4bharat/indic-bert

# CORS
CORS_ORIGINS=http://localhost:3000
EOF

# IMPORTANT: Replace YOUR_USER and YOUR_PASSWORD with your PostgreSQL credentials
# Also update contract addresses with actual ones from migration
```

**Verify configuration:**
```bash
cat .env
# Check that all values are set correctly
```

---

## STEP 9: Start Backend Server

**Open ANOTHER new terminal:**

```bash
cd multilingual-fake-news-detection/backend

# Activate virtual environment
source ../venv/bin/activate  # Linux/Mac
# OR
..\venv\Scripts\activate      # Windows

# Initialize database tables
python << 'EOF'
from app import app, db
with app.app_context():
    db.create_all()
    print("✓ Database tables created")
EOF

# Start Flask server
python app.py

# Expected output:
# * Serving Flask app 'app'
# * Debug mode: on
# WARNING: This is a development server. Do not use it in a production deployment.
# * Running on all addresses (0.0.0.0)
# * Running on http://127.0.0.1:5000
# * Running on http://192.168.1.x:5000
```

**Test the API:**
```bash
# In a new terminal
curl http://localhost:5000/api/health

# Should return:
# {"status": "ok"}
```

---

## STEP 10: Start Frontend

**Open ANOTHER new terminal:**

```bash
cd multilingual-fake-news-detection/frontend

# Install dependencies (first time only, takes ~5 minutes)
npm install

# Start development server
npm start

# Expected output:
# Compiled successfully!
# 
# You can now view multilingual-fake-news-detection in the browser.
# 
#   Local:            http://localhost:3000
#   On Your Network:  http://192.168.1.x:3000
```

**Browser should automatically open to http://localhost:3000**

---

## ✅ VERIFICATION

You should now have 4 terminals running:

1. **Terminal 1**: Ganache blockchain (`ganache-cli`)
2. **Terminal 2**: Flask backend (`python app.py`)
3. **Terminal 3**: React frontend (`npm start`)
4. **Terminal 4**: Your main terminal for testing

---

## 🧪 TEST THE SYSTEM

### Test 1: Analyze Hindi Fake News

In the web interface:

1. Select language: **Hindi**
2. Paste this fake news sample:
```
कोरोना वायरस से बचने के लिए गर्म पानी पीना काफी है। यह वायरस गर्म पानी से मर जाता है।
```
3. Click "Analyze Article"

**Expected result:**
- Prediction: **FAKE** (90%+ confidence)
- Highlighted words: कोरोना, वायरस, गर्म पानी
- Blockchain: Not verified (unless registered)

### Test 2: Analyze Hindi Real News

1. Select language: **Hindi**
2. Paste this real news sample:
```
भारत सरकार ने आज नई शिक्षा नीति 2020 की घोषणा की। इस नीति के तहत स्कूली शिक्षा में कई महत्वपूर्ण बदलाव किए जाएंगे।
```
3. Click "Analyze Article"

**Expected result:**
- Prediction: **REAL** (80%+ confidence)
- Highlighted words: भारत सरकार, शिक्षा नीति, घोषणा

### Test 3: Check API Directly

```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "text": "यह एक परीक्षण संदेश है।",
    "language": "hindi"
  }'

# Should return JSON with prediction, confidence, explanation, etc.
```

---

## 🎉 SUCCESS!

If all tests pass, you have successfully set up the complete system!

---

## 🛑 COMMON ISSUES & SOLUTIONS

### Issue: Backend won't start - "Model not found"

**Solution:**
```bash
# Verify model exists
ls -lh data/models/best_model.pth

# If missing, you need to train the model (Step 6) or download pre-trained
```

### Issue: Frontend won't connect to backend - CORS error

**Solution:**
```bash
# Check backend .env file
cat backend/.env | grep CORS_ORIGINS

# Should be:
CORS_ORIGINS=http://localhost:3000

# Restart backend after changing
```

### Issue: Blockchain connection failed

**Solution:**
```bash
# Check Ganache is running
curl http://localhost:8545
# Should return: {"jsonrpc":"2.0","id":...}

# Verify contract addresses in backend/.env match deployed addresses
```

### Issue: PostgreSQL connection failed

**Solution:**
```bash
# Test connection
psql -U YOUR_USER -d fakenews -c "SELECT 1"

# If fails, check username/password in backend/.env
# DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/fakenews
```

### Issue: Out of memory during inference

**Solution:**
Edit `backend/config.py`:
```python
# Reduce batch size or use CPU
DEVICE = 'cpu'  # Force CPU if GPU memory insufficient
```

### Issue: Model gives poor predictions

**Solution:**
1. Verify you're using the correct language
2. Check text is properly formatted (not corrupted)
3. Ensure model was fully trained
4. Try retraining with more epochs

---

## 📱 NEXT STEPS

Now that your system is running:

1. **Create test accounts**: Register users with different roles
2. **Register publishers**: Add verified publishers to blockchain
3. **Submit articles**: Test with various languages and content
4. **Add annotations**: Practice fact-checking workflow
5. **Submit feedback**: Improve model with corrections

**Admin panel**: http://localhost:3000/admin (requires login)

---

## 🔄 DAILY STARTUP

After initial setup, start the system with:

```bash
# Terminal 1: Blockchain
ganache-cli --deterministic

# Terminal 2: Backend
cd backend && source ../venv/bin/activate && python app.py

# Terminal 3: Frontend
cd frontend && npm start
```

---

## 🛑 SHUTDOWN

```bash
# Stop each service with Ctrl+C in respective terminals
# Or kill all at once:
pkill -f ganache-cli
pkill -f "python app.py"
pkill -f "npm start"
```

---

## 📞 NEED HELP?

- **Documentation**: See README.md
- **Detailed guide**: See IMPLEMENTATION_PLAN.md
- **Issues**: Check troubleshooting section above
- **Still stuck?**: Open GitHub issue with error logs

---

**Happy detecting! 🎯**
