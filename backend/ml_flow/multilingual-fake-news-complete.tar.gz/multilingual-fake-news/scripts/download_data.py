#!/usr/bin/env python3
"""
Download and prepare multilingual fake news dataset from Zenodo
"""
import os
import zipfile
import requests
from pathlib import Path
from tqdm import tqdm

# Dataset URLs from Zenodo record 11408513
DATASET_URLS = {
    'hindi': 'https://zenodo.org/record/11408513/files/Hindi_F%26R_News.zip',
    'gujarati': 'https://zenodo.org/record/11408513/files/Gujarati_F%26R_News.zip',
    'marathi': 'https://zenodo.org/record/11408513/files/Marathi_F%26R_News.zip',
    'telugu': 'https://zenodo.org/record/11408513/files/Telugu_F%26R_News.zip'
}

def download_file(url, destination):
    """Download file with progress bar"""
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    
    with open(destination, 'wb') as f, tqdm(
        desc=destination.name,
        total=total_size,
        unit='iB',
        unit_scale=True,
        unit_divisor=1024,
    ) as pbar:
        for chunk in response.iter_content(chunk_size=8192):
            size = f.write(chunk)
            pbar.update(size)

def extract_zip(zip_path, extract_dir):
    """Extract zip file"""
    print(f"Extracting {zip_path.name}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
    print(f"✓ Extracted to {extract_dir}")

def main():
    """Main download function"""
    # Create data directory
    data_dir = Path('data/raw')
    data_dir.mkdir(parents=True, exist_ok=True)
    
    print("=" * 60)
    print("Multilingual Fake News Dataset Download")
    print("=" * 60)
    print(f"Source: Zenodo Record 11408513")
    print(f"Destination: {data_dir.absolute()}")
    print(f"Languages: {', '.join(DATASET_URLS.keys())}")
    print("=" * 60)
    
    for lang, url in DATASET_URLS.items():
        print(f"\n[{lang.upper()}]")
        
        zip_path = data_dir / f'{lang}.zip'
        extract_dir = data_dir / f'{lang.capitalize()}_F&R_News'
        
        # Download if not exists
        if not zip_path.exists():
            print(f"Downloading {lang} dataset...")
            try:
                download_file(url, zip_path)
                print(f"✓ Downloaded {zip_path.name} ({zip_path.stat().st_size / 1024 / 1024:.1f} MB)")
            except Exception as e:
                print(f"✗ Failed to download {lang}: {e}")
                continue
        else:
            print(f"✓ {zip_path.name} already downloaded ({zip_path.stat().st_size / 1024 / 1024:.1f} MB)")
        
        # Extract if not exists
        if not extract_dir.exists():
            try:
                extract_zip(zip_path, extract_dir)
            except Exception as e:
                print(f"✗ Failed to extract {lang}: {e}")
                continue
        else:
            print(f"✓ Already extracted to {extract_dir.name}")
        
        # Count files
        try:
            # Try to find the subdirectories
            fake_dirs = list(extract_dir.rglob('*fake*'))
            real_dirs = list(extract_dir.rglob('*real*'))
            
            fake_count = 0
            real_count = 0
            
            for fake_dir in fake_dirs:
                if fake_dir.is_dir():
                    fake_count += len(list(fake_dir.glob('*.txt')))
            
            for real_dir in real_dirs:
                if real_dir.is_dir():
                    real_count += len(list(real_dir.glob('*.txt')))
            
            print(f"  → Fake news: {fake_count} articles")
            print(f"  → Real news: {real_count} articles")
            print(f"  → Total: {fake_count + real_count} articles")
        except Exception as e:
            print(f"  → Could not count files: {e}")
    
    print("\n" + "=" * 60)
    print("✓ Dataset download complete!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Run: python scripts/prepare_dataset.py")
    print("2. Run: python scripts/train_model.py")

if __name__ == '__main__':
    main()
