#!/usr/bin/env python3
"""
Prepare multilingual fake news dataset for training
Loads text files from each language folder and creates unified CSV
"""
import pandas as pd
from pathlib import Path
from tqdm import tqdm
import re

def clean_text(text):
    """Basic text cleaning"""
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Remove empty lines
    text = '\n'.join([line.strip() for line in text.split('\n') if line.strip()])
    return text

def load_language_dataset(lang_dir):
    """
    Load fake and real news for one language
    
    Expected structure:
    lang_dir/
        {Language}_fake_news/
            article1.txt
            article2.txt
            ...
        {Language}_real_news/
            article1.txt
            article2.txt
            ...
    """
    lang_name = lang_dir.name.split('_')[0].lower()
    
    # Find fake and real news directories
    fake_dirs = list(lang_dir.rglob('*fake*'))
    real_dirs = list(lang_dir.rglob('*real*'))
    
    data = []
    
    # Load fake news
    for fake_dir in fake_dirs:
        if fake_dir.is_dir():
            txt_files = list(fake_dir.glob('*.txt'))
            print(f"  Loading {len(txt_files)} fake news articles...")
            
            for txt_file in tqdm(txt_files, desc=f"{lang_name} fake"):
                try:
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            data.append({
                                'text': clean_text(text),
                                'label': 0,  # 0 = fake
                                'language': lang_name,
                                'filename': txt_file.name
                            })
                except Exception as e:
                    print(f"    Error reading {txt_file.name}: {e}")
    
    # Load real news
    for real_dir in real_dirs:
        if real_dir.is_dir():
            txt_files = list(real_dir.glob('*.txt'))
            print(f"  Loading {len(txt_files)} real news articles...")
            
            for txt_file in tqdm(txt_files, desc=f"{lang_name} real"):
                try:
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        text = f.read().strip()
                        if text:
                            data.append({
                                'text': clean_text(text),
                                'label': 1,  # 1 = real
                                'language': lang_name,
                                'filename': txt_file.name
                            })
                except Exception as e:
                    print(f"    Error reading {txt_file.name}: {e}")
    
    return pd.DataFrame(data)

def analyze_dataset(df):
    """Print dataset statistics"""
    print("\n" + "=" * 60)
    print("DATASET STATISTICS")
    print("=" * 60)
    
    print(f"\nTotal articles: {len(df):,}")
    
    print("\n--- By Language ---")
    lang_counts = df['language'].value_counts()
    for lang, count in lang_counts.items():
        print(f"{lang.capitalize():12} {count:6,} ({count/len(df)*100:.1f}%)")
    
    print("\n--- By Label ---")
    label_counts = df['label'].value_counts()
    label_names = {0: 'Fake', 1: 'Real'}
    for label, count in label_counts.items():
        print(f"{label_names[label]:12} {count:6,} ({count/len(df)*100:.1f}%)")
    
    print("\n--- By Language and Label ---")
    cross_tab = pd.crosstab(df['language'], df['label'], margins=True)
    cross_tab.columns = ['Fake', 'Real', 'Total']
    print(cross_tab)
    
    print("\n--- Text Length Statistics (characters) ---")
    df['text_length'] = df['text'].str.len()
    print(df.groupby('language')['text_length'].describe())
    
    print("\n--- Sample Articles ---")
    for lang in df['language'].unique():
        print(f"\n{lang.upper()} (Fake):")
        sample = df[(df['language'] == lang) & (df['label'] == 0)].iloc[0]['text']
        print(f"  {sample[:200]}...")
        
        print(f"\n{lang.upper()} (Real):")
        sample = df[(df['language'] == lang) & (df['label'] == 1)].iloc[0]['text']
        print(f"  {sample[:200]}...")

def create_unified_dataset():
    """Combine all languages into single dataset"""
    raw_dir = Path('data/raw')
    
    if not raw_dir.exists():
        print(f"Error: {raw_dir} does not exist!")
        print("Please run: python scripts/download_data.py first")
        return
    
    all_data = []
    
    print("=" * 60)
    print("LOADING MULTILINGUAL DATASET")
    print("=" * 60)
    
    # Find all language folders
    lang_folders = sorted([d for d in raw_dir.glob('*_F&R_News') if d.is_dir()])
    
    if not lang_folders:
        # Try alternate pattern
        lang_folders = sorted([d for d in raw_dir.glob('*_News') if d.is_dir()])
    
    if not lang_folders:
        print(f"Error: No dataset folders found in {raw_dir}")
        print("Expected folders matching pattern: *_F&R_News or *_News")
        return
    
    print(f"Found {len(lang_folders)} language folders:")
    for folder in lang_folders:
        print(f"  - {folder.name}")
    
    # Load each language
    for lang_folder in lang_folders:
        print(f"\n[{lang_folder.name}]")
        df = load_language_dataset(lang_folder)
        
        if len(df) > 0:
            all_data.append(df)
            print(f"✓ Loaded {len(df):,} articles")
        else:
            print(f"⚠ No articles found in {lang_folder.name}")
    
    if not all_data:
        print("\nError: No data loaded!")
        return
    
    # Combine all languages
    print("\n" + "=" * 60)
    print("COMBINING DATASETS")
    print("=" * 60)
    
    combined_df = pd.concat(all_data, ignore_index=True)
    print(f"✓ Combined {len(combined_df):,} articles from {len(all_data)} languages")
    
    # Shuffle
    print("Shuffling dataset...")
    combined_df = combined_df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # Save
    output_dir = Path('data/processed')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = output_dir / 'multilingual_dataset.csv'
    print(f"Saving to {output_file}...")
    combined_df.to_csv(output_file, index=False)
    print(f"✓ Saved {len(combined_df):,} articles to {output_file}")
    
    # Also save train/val/test splits
    from sklearn.model_selection import train_test_split
    
    # Stratified split by language and label
    train_df, temp_df = train_test_split(
        combined_df, 
        test_size=0.3, 
        stratify=combined_df[['language', 'label']], 
        random_state=42
    )
    
    val_df, test_df = train_test_split(
        temp_df, 
        test_size=0.5, 
        stratify=temp_df[['language', 'label']], 
        random_state=42
    )
    
    train_df.to_csv(output_dir / 'train.csv', index=False)
    val_df.to_csv(output_dir / 'val.csv', index=False)
    test_df.to_csv(output_dir / 'test.csv', index=False)
    
    print(f"\n✓ Split into:")
    print(f"  - Training:   {len(train_df):6,} ({len(train_df)/len(combined_df)*100:.1f}%)")
    print(f"  - Validation: {len(val_df):6,} ({len(val_df)/len(combined_df)*100:.1f}%)")
    print(f"  - Testing:    {len(test_df):6,} ({len(test_df)/len(combined_df)*100:.1f}%)")
    
    # Statistics
    analyze_dataset(combined_df)
    
    print("\n" + "=" * 60)
    print("✓ DATASET PREPARATION COMPLETE!")
    print("=" * 60)
    print(f"\nFiles created in {output_dir}:")
    print(f"  - multilingual_dataset.csv (full dataset)")
    print(f"  - train.csv (70%)")
    print(f"  - val.csv (15%)")
    print(f"  - test.csv (15%)")
    print("\nNext step:")
    print("  python scripts/train_model.py")

if __name__ == '__main__':
    create_unified_dataset()
